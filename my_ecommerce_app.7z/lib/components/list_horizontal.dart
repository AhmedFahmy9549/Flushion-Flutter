import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:my_ecommerce_app/db/produt_services.dart';
import 'package:my_ecommerce_app/screens/categories.dart';

class HorizontalList1 extends StatefulWidget {
  @override
  _HorizontalList1State createState() => _HorizontalList1State();
}

class _HorizontalList1State extends State<HorizontalList1> {
  CategoryServices categoryServices = new CategoryServices();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      child: StreamBuilder<QuerySnapshot>(
        stream: categoryServices.getCategory(),
        builder: (context, snapshot) {
        /*  if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Text("Loading... "),
            );
          } else {*/
          if (!snapshot.hasData || snapshot.data == null) {
            print("retrieve users do not have data.");
            return Container();
          }
            return ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: snapshot.data.documents.length,
                itemBuilder: (context, index) {
                  final DocumentSnapshot userDoc = snapshot.data.documents[index];
                  String catgName=userDoc["catgeory"];
                  return Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: InkWell(
                      onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (context)=>CategoriesPage(catgName) ) ),
                      child: Container(
                        width: 100,
                        child: ListTile(
                          title: Image.network(
                            userDoc["image"],
                            width: 100,
                            height: 80,
                          ),
                          subtitle: Container(
                              alignment: Alignment.topCenter,
                              child: Text(
                                catgName,
                                style: new TextStyle(
                                    fontSize: 15, fontWeight: FontWeight.w900),
                              )),
                        ),
                      ),
                    ),
                  );
                });

        },
      ),
    );
  }
}

class HorizontalList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
        height: 100,
        child: new ListView(
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Category(
              catImage: "assets/images/cats/tshirt.png",
              catText: "shirt",
            ),
            Category(
              catImage: "assets/images/cats/dress.png",
              catText: "dress",
            ),
            Category(
              catImage: "assets/images/cats/jeans.png",
              catText: "pants",
            ),
            Category(
              catImage: "assets/images/cats/formal.png",
              catText: "formal",
            ),
            Category(
              catImage: "assets/images/cats/informal.png",
              catText: "informal",
            ),
            Category(
              catImage: "assets/images/cats/shoe.png",
              catText: "shoe",
            ),
            Category(
              catImage: "assets/images/cats/accessories.png",
              catText: "accessories",
            ),
          ],
        ));
  }
}

class Category extends StatelessWidget {
  final String catText;
  final String catImage;

  Category({this.catText, this.catImage});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: InkWell(
        onTap: () {},
        child: Container(
          width: 100,
          child: ListTile(
            title: Image.asset(
              catImage,
              width: 100,
              height: 80,
            ),
            subtitle: Container(
                alignment: Alignment.topCenter,
                child: Text(
                  catText,
                  style:
                      new TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
                )),
          ),
        ),
      ),
    );
  }

  getData() {}
}
