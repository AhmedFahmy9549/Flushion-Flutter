import 'package:flutter/material.dart';
import 'package:my_ecommerce_app/screens/home_screen.dart';
import 'package:my_ecommerce_app/screens/login.dart';


void main (){

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Login(),
    );
  }
}