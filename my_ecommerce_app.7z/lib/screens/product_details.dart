import 'package:flutter/material.dart';
import 'package:my_ecommerce_app/models/product_model.dart';
import 'package:my_ecommerce_app/screens/home.dart';

class ProductDetails extends StatefulWidget {

  final ProductModel model;

  ProductDetails(this.model);

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        backgroundColor: Colors.red,
        title:InkWell(child: Text(widget.model.prodName),onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context){
            return HomePage();
          }));
        }),
      ),
      body: ListView(
        children: <Widget>[
          Container(
            height: 300,
            color: Colors.black,
            child: GridTile(
              child: Container(
                color: Colors.white,
                child: Image.network(widget.model.prodImage),
              ),
              footer: Container(
                color: Colors.white70,
                child: ListTile(
                  leading: Text(
                    widget.model.prodName,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  title: Row(
                    children: <Widget>[
                      Expanded(
                          child: Text(
                            "\$${widget.model.prodPrice+27}",
                            style: TextStyle(
                                fontSize: 18.0,
                                decoration: TextDecoration.lineThrough),
                          )),
                      Expanded(
                        child: Text(
                          "\$${widget.model.prodPrice}",
                          style: TextStyle(
                              color: Colors.red,
                              fontSize: 20,
                              fontWeight: FontWeight.w800),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
          Container(
            color: Colors.white,
            child: Row(
              children: <Widget>[
                Expanded(
                  child: MaterialButton(
                    elevation: 0.2,
                    onPressed: sizeAlertDialog,
                    textColor: Colors.grey,
                    color: Colors.white,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Text("Size"),
                        ),
                        Expanded(
                          child: Icon(Icons.arrow_drop_down),
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: MaterialButton(
                    elevation: 0.2,
                    onPressed: colorAlertDialog,
                    textColor: Colors.grey,
                    color: Colors.white,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Text("Color"),
                        ),
                        Expanded(
                          child: Icon(Icons.arrow_drop_down),
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: MaterialButton(
                    elevation: 0.2,
                    onPressed:  qtyAlertDialog,
                    textColor: Colors.grey,
                    color: Colors.white,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Text("Qty"),
                        ),
                        Expanded(
                          child: Icon(Icons.arrow_drop_down),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: <Widget>[
              Expanded(
                child: MaterialButton(
                  onPressed: () {},
                  color: Colors.red,
                  elevation: 0.2,
                  textColor: Colors.white,
                  child: Text("Buy now"),
                ),
              ),
              IconButton(
                onPressed: () {},
                color: Colors.red,
                icon: Icon(Icons.shopping_cart),
              ),
              IconButton(
                onPressed: () {},
                color: Colors.red,
                icon: Icon(Icons.favorite_border),
              )
            ],
          ),
          Divider(),
          ListTile(
            title: Text("Product details"),
            subtitle: Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."),
          ),
          Divider(),

          Row(
            children: <Widget>[
              Padding(
                padding:const EdgeInsets.fromLTRB(12.0,5.0,5.0,5.0),
                child: Text("Product name",style: TextStyle(color: Colors.grey),),
              ),
              Padding(padding: EdgeInsets.all(5.0),
                child: Text(widget.model.prodName),
              )
            ],
          ),
          Row(
            children: <Widget>[
              Padding(
                padding:const EdgeInsets.fromLTRB(12.0,5.0,5.0,5.0),
                child: Text("Product brand",style: TextStyle(color: Colors.grey),),
              ),  Padding(padding: EdgeInsets.all(5.0),
                child: Text("${widget.model.prodBrand}"),
              )
            ],
          ),
          Row(
            children: <Widget>[
              Padding(
                padding:const EdgeInsets.fromLTRB(12.0,5.0,5.0,5.0),
                child: Text("Product condition",style: TextStyle(color: Colors.grey),),
              ),  Padding(padding: EdgeInsets.all(5.0),
                child: Text("NEW"),
              )
            ],
          ),

        ],
      ),
    );
  }

  sizeAlertDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Size"),
            content: Text("Choose the size"),
            actions: <Widget>[
              new MaterialButton(onPressed: () {
                Navigator.of(context).pop(context);
              },child: Text("close",),)
            ],
          );
        });
  }

  colorAlertDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Color"),
            content: Text("Choose the Color"),
            actions: <Widget>[
              new MaterialButton(onPressed: () {
                Navigator.of(context).pop(context);
              },child: Text("close",))
            ],
          );
        });
  }

  qtyAlertDialog() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Quantity"),
            content: Text("Choose the Quantity"),
            actions: <Widget>[
              new MaterialButton(onPressed: () {
                Navigator.of(context).pop(context);
              },child: Text("close",))
            ],
          );
        });
  }
}



