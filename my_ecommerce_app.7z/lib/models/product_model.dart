class ProductModel {
  String prodName;
  String prodId;
  String prodCategory;
  String prodBrand;
  String prodImage;
  int prodPrice;
  int prodOldPrice;
  int quantity;
  int colors;
  List<String> sizes;

  ProductModel(
      {this.prodName,
      this.prodId,
      this.prodCategory,
      this.prodBrand,
      this.prodImage,
      this.prodPrice,
      this.prodOldPrice,
      this.quantity,
      this.colors,
      this.sizes});


  Map<String,dynamic> toMap(){
    var map=<String,dynamic>{
      "id":prodId,
      "name":prodName,
      "category":prodCategory,
      "image":prodImage,
      "brand":prodBrand,
      "price":prodPrice,
      "quantity":quantity ,
    };

    return map;
  }

}
