import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter/material.dart';

import 'package:my_ecommerce_app/components/list_horizontal.dart';
import 'package:my_ecommerce_app/components/recent_product.dart';
import 'package:my_ecommerce_app/provider/cart_provider.dart';
import 'package:my_ecommerce_app/provider/user_provider.dart';
import 'package:provider/provider.dart';

import 'cart.dart';

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return StateHomePage();
  }
}

class StateHomePage extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
   final bloc = Provider.of<CartProvider>(context);
    final user = Provider.of<UserProvider>(context);

    // TODO: implement build
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        //backgroundColor: Colors.red,
        title: Text("FashApp"),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
          new Padding(
            padding: const EdgeInsets.all(10.0),
            child: new Container(
                height: 150.0,
                width: 30.0,
                child: new GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CartPage(),
                      ),
                    );
                  },
                  child: new Stack(
                    children: <Widget>[
                      new IconButton(
                        icon: new Icon(
                          Icons.shopping_cart,
                          color: Colors.white,
                        ),
                        onPressed: null,
                      ),
                      new Positioned(
                          child: new Stack(
                            children: <Widget>[
                              new Icon(Icons.brightness_1,
                                  size: 20.0, color: Colors.green[700]),
                              new Positioned(
                                  top: 3.0,
                                  right: 7,
                                  child: new Center(
                                    child: new Text("${bloc.getCount()}"
                                      ,
                                      style: new TextStyle(
                                          color: Colors.white,
                                          fontSize: 12.0,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  )),
                            ],
                          )),
                    ],
                  ),
                )),
          )
        ],
      ),
      drawer: new Drawer(
        child: new ListView(
          padding: EdgeInsets.all(0.0),
          children: <Widget>[
            //Header
            new UserAccountsDrawerHeader(
              accountName: Text("Ahmed Fahmy"),
              accountEmail: Text("ahmedmf95@gmai.com"),
              currentAccountPicture: GestureDetector(
                child: CircleAvatar(
                  backgroundColor: Colors.grey,
                  child: Icon(
                    Icons.person,
                    color: Colors.white,
                  ),
                ),
              ),
              decoration: new BoxDecoration(color: Colors.red),
            ),

            //Body
            InkWell(
                onTap: () {},
                child: new ListTile(
                  title: Text("Home Page"),
                  leading: Icon(
                    Icons.home,
                    color: Colors.red,
                  ),
                )),
            InkWell(
                onTap: () {},
                child: new ListTile(
                  title: Text("My account"),
                  leading: Icon(
                    Icons.person,
                    color: Colors.red,
                  ),
                )),
            InkWell(
                onTap: () {},
                child: new ListTile(
                  title: Text("My Orders"),
                  leading: Icon(
                    Icons.shopping_basket,
                    color: Colors.red,
                  ),
                )),
            InkWell(
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (context) => CartPage())),
                child: new ListTile(
                  title: Text("Shopping cart"),
                  leading: Icon(
                    Icons.shopping_cart,
                    color: Colors.red,
                  ),
                )),
            InkWell(
                onTap: () {},
                child: new ListTile(
                  title: Text("Favourites"),
                  leading: Icon(
                    Icons.favorite,
                    color: Colors.red,
                  ),
                )),

            Divider(),

            InkWell(
                onTap: () {
                    user.signOut();
                },
                child: new ListTile(
                  title: Text("SignOut"),
                  leading: Icon(
                    Icons.exit_to_app,
                    color: Colors.blue,
                  ),
                )),

            InkWell(
                onTap: () {},
                child: new ListTile(
                  title: Text("About"),
                  leading: Icon(
                    Icons.help,
                    color: Colors.green,
                  ),
                )),
          ],
        ),
      ),
      body:  Column(
        children: <Widget>[
          //Image Carousel initialized
          getImageCarousel(),
          new Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Categroies",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              )),

          //initialize Horizontal listView
          HorizontalList1(),

          Padding(
            padding: EdgeInsets.all(10.0),
            child: Container(
              alignment: Alignment.centerLeft,
              child: Text(
                "Recent Produts",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
          ),

          Flexible(child: Product()),
        ],
      ),
    );
  }

  Widget getImageCarousel() {
    return Container(
      height: 200,
      child: Carousel(
        boxFit: BoxFit.cover,
        images: [
          AssetImage("assets/images/w3.jpeg"),
          AssetImage("assets/images/c1.jpg"),
          AssetImage("assets/images/m1.jpeg"),
          AssetImage("assets/images/w4.jpeg"),
          AssetImage("assets/images/m2.jpg"),
        ],
        autoplay: false,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(microseconds: 1000),
        dotSize: 4.0,
        //dotColor: Colors.red,
        //dotBgColor: Colors.transparent,
        indicatorBgPadding: 4.0,
      ),
    );
  }
}
