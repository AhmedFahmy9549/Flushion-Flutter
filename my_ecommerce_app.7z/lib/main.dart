import 'package:flutter/material.dart';
import 'package:my_ecommerce_app/provider/cart_provider.dart';
import 'package:my_ecommerce_app/provider/user_provider.dart';
import 'package:my_ecommerce_app/screens/home.dart';
import 'package:my_ecommerce_app/screens/login.dart';
import 'package:provider/provider.dart';


void main() {
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(builder: (context) => CartProvider()),
      ChangeNotifierProvider(builder: (context) => UserProvider.initialize()),
    ],
    child: MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: Colors.red),
      home: ScreensController(),
    ),
  ));
}

class ScreensController extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserProvider>(context);
    switch (user.status) {
      case Status.UnInitialized:
        print("Status From Main = ${user.status}");
        return Login();
      case Status.Authenticated:
        print("Status From Main = ${user.status}");
        return HomePage();
      case Status.UnAuthenticated:
        print("Status From Main = ${user.status}");
        return Login();

      case Status.Authenticating:
        print("Status From Main = ${user.status}");
        return Login();

      default:
        print("Status From Main = ${user.status}");
        return Login();
    }
  }
}

class Splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return null;
  }
}
